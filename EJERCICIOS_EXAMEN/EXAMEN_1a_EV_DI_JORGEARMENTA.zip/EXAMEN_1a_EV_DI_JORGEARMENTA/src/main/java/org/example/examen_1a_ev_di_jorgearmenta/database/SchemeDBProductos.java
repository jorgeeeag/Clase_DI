package org.example.examen_1a_ev_di_jorgearmenta.database;

public interface SchemeDBProductos {
    String URL="127.0.0.1";
    String PORT="3306";

    String DB_NAME="javafx";
    String TAB_NAME="productos";
    String COL_ID="id";
    String COL_NOMBRE="nombre";
    String COL_CATEGORIA="categoria";
    String COL_PRECIO="precio";
}
