package org.example.examen_1a_ev_di_jorgearmenta.database;

public interface SchemeDBUsuarios {
    String URL="127.0.0.1";
    String PORT="3306";

    String DB_NAME="javafx";
    String TAB_NAME="usuarios";
    String COL_ID="id";
    String COL_NOMBRE="nombre";
    String COL_CORREO="correo";
    String COL_PASS="pass";
}
