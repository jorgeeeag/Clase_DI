package model;

public interface Descargable {
    void calcularTiempoDescarga(double velocidadInternet);
    void obtenerTamañoGB();
}
