package model;

public interface Planificable {
    int getid();

    int getId();
}
